from base64 import decode
from calendar import month
from multiprocessing.connection import Client
from operator import truediv
import tkinter as tk
from tkinter.ttk import *
from tkinter import *
import socket
from tkinter import Button, Frame, font
from tkinter.constants import BOTTOM, COMMAND, FALSE
from turtle import showturtle, width, window_height, window_width
from PIL import Image, ImageTk
from tkinter import messagebox
from setuptools import Command
from datetime import datetime
from datetime import time
from datetime import date

#connect server
HOST = "127.0.0.1"
SERVER_PORT = 65500
FORMAT = "utf-8"

client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
w1 = 0
w2 = 0
w3 = 0
r1 = 0
r2 = 0
r3 = 0
ks=""
pic=""
print("CLIENT SIDE")
try:
    client.connect((HOST,SERVER_PORT))
    print("Client address:",client.getsockname())
    print("Connect success to the server!")
except :
    messagebox.showinfo("Error","Sever hiện chưa hoạt động")
    print("Connection error")
    exit()


def recvlist(client):
    info = []
    msg = client.recv(1024).decode(FORMAT)

    while msg != "end":
        info.append(msg)
        client.send(msg.encode(FORMAT))
        msg = client.recv(1024).decode(FORMAT)        

    return info

#get_info
def get_info(txt1,txt2):
    user=txt1.get()
    password=txt2.get()
    print(user)

#outputroominfo
def outputRoomInfo(mylist,room):
    mylist.insert(END,"Mã phòng: " + room[0])
    if room[1] == '0':
        mylist.insert(END,"Trạng thái: Trống")
    else:
        mylist.insert(END,"Trạng thái: Đã được đặt")
    mylist.insert(END,"Loại phòng: Loại " + room[2])
    mylist.insert(END,"Giá tiền: " + room[3] + " VNĐ")

#outputroominfo dành cho hóa đơn
def outputRoomInfo2(mylist,room):
    mylist.insert(END,"Mã phòng: " + room[0])
    mylist.insert(END,"Loại phòng: Loại " + room[2])
    mylist.insert(END,"Giá tiền: " + room[3] + " VNĐ")
#sendlist
def sendlist(client, info):
    for item in info:
        client.send(item.encode(FORMAT))
        client.recv(1024)
    client.send("end".encode(FORMAT))

#sendlist lv2
def sendlist_lv2(conn, info):
    for item in info:
        sendlist(conn, item)
        conn.recv(1024)

    sendlist(conn, [])


#recvlist
def recvlist(client):
    info = []
    msg = client.recv(1024).decode(FORMAT)

    while msg != "end":
        info.append(msg)
        client.send(msg.encode(FORMAT))
        msg = client.recv(1024).decode(FORMAT)        

    return info

#recvlist_lv2
def recvlist_lv2(client):
    info = []
    msg = recvlist(client)

    while msg != []:
        info.append(msg)
        client.send("Y".encode(FORMAT))
        msg = recvlist(client)

    return info

#click_login
def click_login(txt1,txt2,master):
    get_info(txt1, txt2)
    user=txt1.get()
    passw=txt2.get()
    if(user=="" or passw==""):
        messagebox.showinfo("Thông báo","Lỗi\nTên đăng nhập và mật khẩu không được bỏ trống")
        return
    account = []
    account.append(user)
    account.append(passw)
    msg="1"
    client.send(msg.encode(FORMAT))
    sendlist(client, account)
    msg = client.recv(1024).decode(FORMAT)
    client.send(msg.encode(FORMAT))
    res=client.recv(1024).decode(FORMAT)
    client.send(res.encode(FORMAT))
    if(res=="True"):
        messagebox.showinfo("Thông báo",msg)
        master.switch_frame(ClientMenu)
    else:
        messagebox.showinfo("Đăng nhập thất bại", msg)

#username check
def usernameCheck(username):
    if len(username) < 5:
        return False

    for i in username:
        if (i < 'a' or i > 'z') and (i < '0' or i > '9'):
            return False
    return True
#password check
def passwordCheck(password):
    if len(password) < 3:
        return False
    return True

#bankid check
def bankidCheck(bankid):
    if len(bankid) != 10:
        return False

    for i in bankid:
        if i < '0' or i > '9':
            return False
    return True

#click_signup
def click_signup(txt1,txt2,txt3,master):
    account = []
    username = txt1.get()
    password = txt2.get()
    bankid = txt3.get()
    if(username=="" or password=="" or bankid==""):
        messagebox.showinfo("Thông báo","Lỗi\nThông tin đăng ký không được bỏ trống")
        return
    elif usernameCheck(username) == False:
        messagebox.showinfo("Lỗi","Username không hợp lệ!")
        return
    elif passwordCheck(password) == False:
        messagebox.showinfo("Lỗi","Password không hợp lệ")
        return
    elif bankidCheck(bankid) == False:
        messagebox.showinfo("Lỗi","Mã thẻ ngân hàng không hợp lệ")
        return
    account.append(username)
    account.append(password)
    account.append(bankid)
    msg="2"
    client.sendall(msg.encode(FORMAT))
    msg = client.recv(1024).decode(FORMAT)
    sendlist(client, account)
    msg = client.recv(1024).decode(FORMAT)
    messagebox.showinfo("Thông báo",msg)
    client.sendall(msg.encode(FORMAT))
    rslt = client.recv(1024).decode(FORMAT)
    client.sendall(rslt.encode(FORMAT))
    if rslt == '0':
        return
    elif rslt == '1':
        master.switch_frame(ClientLogin)
        return 

#kiem tra ngay co dung khong
def kiemtrangay(d,m,y):
    t=0
    if((y%4==0 and y%100!=0) or (y%400==0)):
        t=1
    if(m==2):
        if(d>(28+t)):
           return False
        else:
           return True
    else:
        if(m==4 or m==6 or m==9 or m==11):
            if(d>30):
                return False
            else:
                return True
        else:
            return True

#tinh khoang cach ngay 
def khoangcachngay(d1,m1,y1,d2,m2,y2):
    if(y2<y1):
        return -1
    elif(m2<m1 and y2==y1):
        return -1
    elif(d2<d1 and m2==m1 and y2==y1):
        return -1
    t=0
    while(y2>=y1):
        if(y2==y1 and m2==m1):
            t=t+d2-d1
            return t
        else:
            if(m1==4 or m1==6 or m1==9 or m1==11):
                t=t+30-d1 
            elif(m1==1 or m1==3 or m1==5 or m1==7 or m1==8 or m1==10 or m1==12):
                t=t+31-d1
            elif(m1==2):
                if((y1%4==0 and y1%100!=0) or (y1%400==0)):
                    t=t+29-d1 
                else:
                    t=t+28-d1 
            m1=m1+1
            d1=0
            if(m1==13):
                y1=y1+1
                m1=1
    return t

#ngayden_ngaydi
def nganDen_ngayDi(Day,Month,Year,dn,mn,yn,dt,mt,yt):
    a=str(Day)
    b=str(Month)
    c=str(Year)
    an=str(dn)
    bn=str(mn)
    cn=str(yn)
    at=str(dt)
    bt=str(mt)
    ct=str(yt)
    n0=[a,b,c]
    n1=[an,bn,cn]
    n2=[at,bt,ct]
    n = [n0,n1, n2]
    return n

#xem mô tả khách sạn 
def xemmota(master,hotelname):
    global pic
    kt=False
    tenks=str(hotelname.get())
    for ten in hotelname['values']:
        if(tenks==ten):
            pic=tenks+".png"
            msg="3"
            client.sendall(msg.encode(FORMAT))
            master.switch_frame(Hotelinfo)
            kt=True
    if(kt==False):
        messagebox.showinfo("Thông báo","Khách sạn không tồn tại")
        return 
    
#show ket qua tra cuu
def showsearch(hname,dn,mn,yn,dt,mt,yt,self):
    an=int(dn.get())
    bn=int(mn.get())
    cn=int(yn.get())
    at=int(dt.get())
    bt=int(mt.get())
    ct=int(yt.get())
    case1=kiemtrangay(an,bn,cn)
    if(case1==False):
        messagebox.showinfo("Thông báo","Lỗi\nNgày vào không hợp lệ!")
        return
    case2=kiemtrangay(at,bt,ct)
    if(case2==False):
        messagebox.showinfo("Thông báo","Lỗi\nNgày rời đi không hợp lệ!")
        return
    kc=khoangcachngay(an,bn,cn,at,bt,ct)
    if(kc<0):
        messagebox.showinfo("Thông báo","Lỗi\nNgày vào và ngày trả không hợp lệ!")
        return
    if(an==at and bn==bt and cn==ct):
        messagebox.showinfo("Thông báo","Lỗi\nNgày vào và ngày trả giống nhau!")
        return
    today = date.today()
    Day = today.day
    Month = today.month
    Year = today.year
    kc=khoangcachngay(Day,Month,Year,an,bn,cn)
    if(kc<0):
        Day=str(Day)
        Month=str(Month) 
        Year=str(Year)
        msg="Lỗi\nNgày vào sớm hơn ngày hiện tại!\nNgày hiện tại:" + Day + "/" + Month + "/" + Year
        messagebox.showinfo("Thông báo",msg)
        return
    msg="1"
    client.sendall(msg.encode(FORMAT))
    msg=client.recv(1024).decode(FORMAT)
    hoteln=str(hname.get())
    client.sendall(hoteln.encode(FORMAT))
    msg=client.recv(1024).decode(FORMAT)
    if(msg=="0"):
        messagebox.showinfo("Thông báo","Khách sạn không tồn tại")
        return 

    timePeriod = nganDen_ngayDi(Day,Month,Year,an,bn,cn,at,bt,ct)
    sendlist_lv2(client, timePeriod)
    sparseRoom = recvlist_lv2(client)
    if(sparseRoom==[]):
        messagebox.showinfo("XIN LỖI","Khách sạn hiện đã hết phòng theo yêu cầu ngày của bạn")
        return 

    scrollbar= Scrollbar(self)
    scrollbar.height=400
    scrollbar.place(x=480,y=100,height=400)
    mylist=Listbox(self,width=60,height=12,yscrollcommand=scrollbar.set)
    mylist.insert(END,"Số lượng phòng trống: " + str(len(sparseRoom)) + " phòng")
    mylist.insert(END," ")
    mylist.insert(END,"Danh sách phòng trống:")
    mylist.insert(END," ")
    for room in sparseRoom:
        mylist.insert(END,"Phòng " + str(sparseRoom.index(room) + 1) + ":")
        outputRoomInfo(mylist,room)
        mylist.insert(END," ")
    mylist.place(x=12,y=220)
    scrollbar.config(command=mylist.yview)
    return

#bắt đầu đặt phòng
def begintobookroom(hname,dn,mn,yn,dt,mt,yt,self,master):
    an=int(dn.get())
    bn=int(mn.get())
    cn=int(yn.get())
    at=int(dt.get())
    bt=int(mt.get())
    ct=int(yt.get())
    case1=kiemtrangay(an,bn,cn)
    if(case1==False):
        messagebox.showinfo("Thông báo","Lỗi\nNgày vào không hợp lệ!")
        return
    case2=kiemtrangay(at,bt,ct)
    if(case2==False):
        messagebox.showinfo("Thông báo","Lỗi\nNgày rời đi không hợp lệ!")
        return
    kc=khoangcachngay(an,bn,cn,at,bt,ct)
    if(kc<0):
        messagebox.showinfo("Thông báo","Lỗi\nNgày vào và ngày trả không hợp lệ!")
        return
    if(an==at and bn==bt and cn==ct):
        messagebox.showinfo("Thông báo","Lỗi\nNgày vào và ngày trả giống nhau!")
        return
    today = date.today()
    Day = today.day
    Month = today.month
    Year = today.year
    kc=khoangcachngay(Day,Month,Year,an,bn,cn)
    if(kc<0):
        Day=str(Day)
        Month=str(Month) 
        Year=str(Year)
        msg="Lỗi\nNgày vào sớm hơn ngày hiện tại!\nNgày hiện tại:" + Day + "/" + Month + "/" + Year
        messagebox.showinfo("Thông báo",msg)
        return
    msg="1"
    client.sendall(msg.encode(FORMAT))
    msg=client.recv(1024).decode(FORMAT)
    hoteln=str(hname.get())
    client.sendall(hoteln.encode(FORMAT))
    msg=client.recv(1024).decode(FORMAT)
    if(msg=="0"):
        messagebox.showinfo("Thông báo","Khách sạn không tồn tại")
        return 

    timePeriod = nganDen_ngayDi(Day,Month,Year,an,bn,cn,at,bt,ct)
    sendlist_lv2(client, timePeriod)
    global w1,w2,w3,r1,r2,r3,ks
    w1=0
    w2=0
    w3=0
    ks=client.recv(1024).decode(FORMAT)
    client.sendall(ks.encode(FORMAT))
    r1=client.recv(1024).decode(FORMAT)
    client.sendall(ks.encode(FORMAT))
    r2=client.recv(1024).decode(FORMAT)
    client.sendall(ks.encode(FORMAT))
    r3=client.recv(1024).decode(FORMAT)
    master.switch_frame(Clientready)

#tính số phòng muốn đặt
def sendbookroom1(master,self,r1,r2,r3,typeroom,numroom):
    global w1,w2,w3
    r1=int(r1)
    r2=int(r2)
    r3=int(r3)
    lp=int(typeroom.get())
    if(lp>3 or lp <1):
        messagebox.showinfo("Thông báo","Loại phòng không tồn tại!")
        return
    sl=int(numroom.get())
    if((lp==1 and w1+sl>r1) or (lp==2 and w2+sl>r2) or(lp==3 and w3+sl>r3)):
        messagebox.showinfo("Thông báo","Số lượng phòng loại bạn đặt vượt quá số lượng phòng trống hiện có!")
        return
    if(lp==1):
        w1=w1+sl
    elif(lp==2):
        w2=w2+sl 
    elif(lp==3):
        w3=w3+sl
    master.switch_frame(Booksuccess)

#gửi số phòng đã đặt và nhận thanh toán
def sendbookroom2(master,self):
    global w1,w2,w3,ks
    if(w1==0 and w2==0 and w3==0):
        messagebox.showinfo("Thông báo","Bạn chưa đặt phòng nào!")
        return
    msg="1"
    client.sendall(msg.encode(FORMAT))
    msg=client.recv(1024).decode(FORMAT)
    client.sendall(str(w1).encode(FORMAT))
    msg=client.recv(1024).decode(FORMAT)
    client.sendall(str(w2).encode(FORMAT))
    msg=client.recv(1024).decode(FORMAT)
    client.sendall(str(w3).encode(FORMAT))

    master.switch_frame(Recipt)

#check có phòng đã đặt để hủy
def checkbookedroombeforecancel(master):
    msg="3"
    client.sendall(msg.encode(FORMAT))
    bookedList = recvlist_lv2(client)
    if (bookedList == []):
        messagebox.showinfo("Thông báo","Chưa có thông tin đặt phòng")
        master.switch_frame(ClientMenu)
    else:
        master.switch_frame(ClientCancel)

#xử lý hủy phòng
def canceltheroom(master,hoteldate):
    hten=str(hoteldate.get())
    dd=0
    md=0
    yd=0
    i=0
    dd=int(hten[i])
    i=i+1
    if(hten[i]>="0" and hten[i]<="9"):
        dd=dd*10+int(hten[i])
        i=i+1
    i=i+1
    md=int(hten[i])
    i=i+1
    if(hten[i]>="0" and hten[i]<="9"):
        md=md*10+int(hten[i])
        i=i+1
    for j in range(1,5):
        i=i+1
        yd=yd*10+int(hten[i])
    i=i+2
    hotelname=""
    for j in range(i+1,len(hten)-1):
        hotelname=hotelname+hten[j]
    print(str(dd)+"/"+str(md)+"/"+str(yd))
    today = date.today()
    Day = today.day
    Month = today.month
    Year = today.year
    kc=khoangcachngay(dd,md,yd,Day,Month,Year)
    if(kc>1):
        messagebox.showinfo("Thông báo","Hủy phòng thất bại!\nĐã quá giới hạn 24h.")
        return
    else:
        msg="1"
        client.sendall(msg.encode(FORMAT))
        msg=client.recv(1024).decode(FORMAT)
        client.sendall(hotelname.encode(FORMAT))
        msg=client.recv(1024).decode(FORMAT)
        nDat=[str(dd),str(md),str(yd)]
        sendlist(client,nDat)
        msg=client.recv(1024).decode(FORMAT)
        messagebox.showinfo("Thông báo","Hủy phòng thành công!")
        master.switch_frame(ClientMenu)
#logout
def logout(master):
    messagebox.showinfo("Thông báo","Đăng xuất thành công")
    msg="4"
    client.sendall(msg.encode(FORMAT))
    msg=client.recv(1024).decode(FORMAT)
    master.switch_frame(ClientLogin)

# close-programe function
def on_closing(self):
     if messagebox.askokcancel("Thoát!", "Bạn có muốn thoát?"):
         msg="x"
         client.sendall(msg.encode(FORMAT))
         self.destroy()


#frameapp
class Frameapp(tk.Tk):

    def __init__(self):
        tk.Tk.__init__(self)
        self._frame = None
        self.switch_frame(ClientLogin)

    def switch_frame(self, frame_class):
        """Destroys current frame and replaces it with a new one."""
        new_frame = frame_class(self)
        if self._frame is not None:
            self._frame.destroy()
        self._frame = new_frame
        self._frame.pack()
#frame 1 (LOGIN)
class ClientLogin(tk.Frame):
    def __init__(self, master):
        msg="1"
        client.sendall(msg.encode(FORMAT))
        tk.Frame.__init__(self, master)
        self["bg"] = "#66ffcc"
        self.pack(ipadx=500,ipady=500,expand=True)
        # image
        image1 = Image.open("main.jpg")
        image1 = image1.resize((500, 500))
        test = ImageTk.PhotoImage(image1)

        # lable
        label0 = tk.Label(self, image=test)
        label0.image = test
        label0.place(x=0, y=0)

        # lable
        lb1 = tk.Label(self, text="BOOKING HOTEL", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb1.pack()
        lb2 = tk.Label(self, text="LOGIN", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb2.pack()
        lb3 = tk.Label(self, text="Username:", font=("Times new roman", 20), fg="black", bg="#66ffcc")
        lb3.place(x=50,y=120)  # 0 so voi frame
        lb4 = tk.Label(self, text="Password:", font=("Times new roman", 20), fg="black", bg="#66ffcc")
        lb4.place(x=50,y=170)  # 0 so voi frame
        # textbox
        txt1 = tk.Entry(self, width=20)
        txt2 = tk.Entry(self, width=20)
        txt1.place(x=250, y=120)
        txt2.place(x=250, y=170)

        # button
        bt1 = Button(self, text='login', command=lambda: click_login(txt1,txt2,master)).place(x=150, y=220)
        bt2 = Button(self, text='signup', command=lambda: master.switch_frame(ClientSignup)).place(x=250, y=220)

#frame 2 (SIGN UP)
class ClientSignup(tk.Frame):
    
    def __init__(self, master):
        msg="2"
        client.sendall(msg.encode(FORMAT))
        tk.Frame.__init__(self, master)
        self["bg"] = "#66ffcc"
        self.pack(ipadx=500,ipady=500,expand=True)
        # image
        image1 = Image.open("main.jpg")
        image1 = image1.resize((500, 500))
        test = ImageTk.PhotoImage(image1)

        # lable
        label0 = tk.Label(self, image=test)
        label0.image = test
        label0.place(x=0, y=0)

        # lable
        lb1 = tk.Label(self, text="BOOKING HOTEL", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb1.pack()
        lb2 = tk.Label(self, text="SIGN UP", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb2.pack()
        lb3 = tk.Label(self, text="Username:", font=("Times new roman", 20), fg="black", bg="#66ffcc")
        lb3.place(x=50,y=120)  # 0 so voi frame
        lb4 = tk.Label(self, text="Password:", font=("Times new roman", 20), fg="black", bg="#66ffcc")
        lb4.place(x=50,y=170)  # 0 so voi frame
        lb5 = tk.Label(self, text=" Bank ID:", font=("Times new roman", 20), fg="black", bg="#66ffcc")
        lb5.place(x=50, y=220)  # 0 so voi frame
        # textbox
        txt1 = tk.Entry(self, width=20)
        txt2 = tk.Entry(self, width=20)
        txt3 = tk.Entry(self, width=20)
        txt1.place(x=250, y=120)
        txt2.place(x=250, y=170)
        txt3.place(x=250,y=220)

        # button
        bt1 = Button(self, text='Already have an account', command=lambda: master.switch_frame(ClientLogin)).place(x=80,y=270)
        bt2 = Button(self, text='signup',command=lambda:click_signup(txt1,txt2,txt3,master)).place(x=300, y=270)

#frame 3 (MENU)
class ClientMenu(tk.Frame):
    def __init__(self, master):
        msg="3"
        client.sendall(msg.encode(FORMAT))
        tk.Frame.__init__(self, master)
        self["bg"] = "#66ffcc"
        self.pack(ipadx=500,ipady=500,expand=True)
        # image
        image1 = Image.open("main.jpg")
        image1 = image1.resize((500, 500))
        test = ImageTk.PhotoImage(image1)

        # lable
        label0 = tk.Label(self, image=test)
        label0.image = test
        label0.place(x=0, y=0)

        # lable
        lb1 = tk.Label(self, text="BOOKING HOTEL", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb1.pack()
        lb2 = tk.Label(self, text="Menu", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb2.pack()


        # button
        bt1 = Button(self, text='TRA CỨU', font=("Times new roman", 30), command=lambda: master.switch_frame(ClientSearch)).place(x=140,y=120)
        bt2 = Button(self, text='ĐẶT PHÒNG', font=("Times new roman", 30), command=lambda: master.switch_frame(ClientBook)).place(x=110, y=200)
        bt3 = Button(self, text='HỦY PHÒNG', font=("Times new roman", 30), command=lambda: checkbookedroombeforecancel(master) ).place(x=110, y=280)
        bt3 = Button(self, text='LOG OUT', font=("Times new roman", 10),command=lambda: logout(master)).place(x=50, y=450)

#frame 4 (SEARCH)
class ClientSearch(tk.Frame):
    def __init__(self, master):
        msg="1"
        client.sendall(msg.encode(FORMAT))
        tk.Frame.__init__(self, master)
        self["bg"] = "#66ffcc"
        self.pack(ipadx=500,ipady=500,expand=True)
        # image
        image1 = Image.open("main.jpg")
        image1 = image1.resize((500, 500))
        test = ImageTk.PhotoImage(image1)

        # lable
        label0 = tk.Label(self, image=test)
        label0.image = test
        label0.place(x=0, y=0)

        # lable
        lb1 = tk.Label(self, text="BOOKING HOTEL", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb1.pack()
        lb2 = tk.Label(self, text="TRA CỨU", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb2.pack()
        lb3 = tk.Label(self, text="Chọn khách sạn:", font=("Times new roman", 10), fg="black", bg="#66ffcc")
        lb3.place(x=20, y=120)  # 0 so voi frame
        lb4 = tk.Label(self, text="Ngày vào ở:", font=("Times new roman", 10), fg="black", bg="#66ffcc")
        lb4.place(x=20, y=150)  # 0 so voi frame
        lb5 = tk.Label(self, text="Ngày rời đi:", font=("Times new roman", 10), fg="black", bg="#66ffcc")
        lb5.place(x=20, y=180)  # 0 so voi frame
        
        hotelNameList = recvlist(client)
        #Tạo hộp chọn Combobox
        hname = Combobox(self,width=20,height=10)
        dn = Combobox(self,width=3,height=5)
        mn = Combobox(self,width=4,height=5)
        yn = Combobox(self,width=8,height=5)
        dt = Combobox(self,width=3,height=5)
        mt = Combobox(self,width=4,height=5)
        yt = Combobox(self,width=8,height=5)
        #Các giá trị của hộp chọn
        hname['values']= (hotelNameList)
        dn['values']= (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27 ,28, 29, 30, 31)
        mn['values']=(1,2,3,4,5,6,7,8,9,10,11,12)
        yn['values']=(2022,2023,2024,2025,2026,2027,2028,2029,2030,2031,2032)
        dt['values']= (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27 ,28, 29, 30, 31)
        mt['values']=(1,2,3,4,5,6,7,8,9,10,11,12)
        yt['values']=(2022,2023,2024,2025,2026,2027,2028,2029,2030,2031,2032)
        #Thiết lập giá trị được chọn
        hname.current(0)
        dn.current(0)
        mn.current(0)
        yn.current(0)
        dt.current(0)
        mt.current(0)
        yt.current(0)
        #đặt vào vị trí
        hname.place(x=120,y=120)
        dn.place(x=120,y=150)
        mn.place(x=161,y=150)#+41
        yn.place(x=208,y=150)#+47
        dt.place(x=120,y=180)
        mt.place(x=161,y=180)#+41
        yt.place(x=208,y=180)#+47

        # button
        bt1 = Button(self, text='Search', font=("Times new roman", 12), command=lambda: showsearch(hname,dn,mn,yn,dt,mt,yt,self)).place(x=320, y=150)
        bt2 = Button(self, text='Back', font=("Times new roman", 12), command=lambda: master.switch_frame(ClientMenu)).place(x=20, y=450)
        bt3 = Button(self, text='Xem mô tả', font=("Times new roman", 12),command=lambda: xemmota(master,hname)).place(x=320, y=120)

#frame 5(Hotel review)
class Hotelinfo(tk.Frame):
    def __init__(self, master):
        tk.Frame.__init__(self, master)
        self["bg"] = "#66ffcc"
        self.pack(ipadx=500,ipady=500,expand=True)
        global pic
        # image
        image1 = Image.open(pic)
        image1 = image1.resize((500, 500))
        test = ImageTk.PhotoImage(image1)

        # lable
        label0 = tk.Label(self, image=test)
        label0.image = test
        label0.place(x=0, y=0)
        pic=""

        # lable
        lb1 = tk.Label(self, text="THÔNG TIN KHÁCH SẠN", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb1.pack()


        # button
        bt1 = Button(self, text='Back', font=("Times new roman", 12),command=lambda: master.switch_frame(ClientSearch)).place(x=20, y=50)

#frame 6 (BOOK a ROOM)
class ClientBook(tk.Frame):
    def __init__(self, master):
        msg="2"
        client.sendall(msg.encode(FORMAT))
        tk.Frame.__init__(self, master)
        self["bg"] = "#66ffcc"
        self.pack(ipadx=500,ipady=500,expand=True)
        # image
        image1 = Image.open("main.jpg")
        image1 = image1.resize((500, 500))
        test = ImageTk.PhotoImage(image1)

        # lable
        label0 = tk.Label(self, image=test)
        label0.image = test
        label0.place(x=0, y=0)

        

        # lable
        lb1 = tk.Label(self, text="BOOKING HOTEL", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb1.pack()
        lb2 = tk.Label(self, text="ĐẶT PHÒNG", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb2.pack()
        lb3 = tk.Label(self, text="Chọn khách sạn:", font=("Times new roman", 10), fg="black", bg="#66ffcc")
        lb3.place(x=30, y=120)  # 0 so voi frame
        lb4 = tk.Label(self, text="Ngày vào ở:", font=("Times new roman", 10), fg="black", bg="#66ffcc")
        lb4.place(x=30, y=150)  # 0 so voi frame
        lb5 = tk.Label(self, text="Ngày rời đi:", font=("Times new roman", 10), fg="black", bg="#66ffcc")
        lb5.place(x=30, y=180)  # 0 so voi frame

        hotelNameList = recvlist(client)
        #Tạo hộp chọn Combobox
        hname = Combobox(self,width=30,height=10)
        dn = Combobox(self,width=3,height=5)
        mn = Combobox(self,width=4,height=5)
        yn = Combobox(self,width=8,height=5)
        dt = Combobox(self,width=3,height=5)
        mt = Combobox(self,width=4,height=5)
        yt = Combobox(self,width=8,height=5)
        #Các giá trị của hộp chọn
        hname['values']= (hotelNameList)
        dn['values']= (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27 ,28, 29, 30, 31)
        mn['values']=(1,2,3,4,5,6,7,8,9,10,11,12)
        yn['values']=(2022,2023,2024,2025,2026,2027,2028,2029,2030,2031,2032)
        dt['values']= (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27 ,28, 29, 30, 31)
        mt['values']=(1,2,3,4,5,6,7,8,9,10,11,12)
        yt['values']=(2022,2023,2024,2025,2026,2027,2028,2029,2030,2031,2032)
        #Thiết lập giá trị được chọn
        hname.current(0)
        dn.current(0) #set the selected item
        mn.current(0)
        yn.current(0)
        dt.current(0)
        mt.current(0)
        yt.current(0)
        #đặt vào vị trí
        hname.place(x=140,y=120)
        dn.place(x=140,y=150)
        mn.place(x=181,y=150)#+41
        yn.place(x=228,y=150)#+47
        dt.place(x=140,y=180)
        mt.place(x=181,y=180)#+41
        yt.place(x=228,y=180)#+47

        # button
        bt1 = Button(self, text='Book', font=("Times new roman", 12), command=lambda:begintobookroom(hname,dn,mn,yn,dt,mt,yt,self,master)).place(x=320, y=150)
        bt2 = Button(self, text='Back', command=lambda: master.switch_frame(ClientMenu)).place(x=20, y=450)

#frame 7 (BOOK ROOM TYPE)
class Clientready(tk.Frame):
    def __init__(self, master):
        tk.Frame.__init__(self, master)
        self["bg"] = "#66ffcc"
        self.pack(ipadx=500,ipady=500,expand=True)
        # image
        image1 = Image.open("main.jpg")
        image1 = image1.resize((500, 500))
        test = ImageTk.PhotoImage(image1)

        # lable
        label0 = tk.Label(self, image=test)
        label0.image = test
        label0.place(x=0, y=0)

        #nhận số lượng mỗi loại phòng

        mylist=Listbox(self,width=60,height=12)
        global w1,w2,w3,r1,r2,r3,ks
        mylist.insert(END,"Khách sạn "+ks)
        mylist.insert(END,"Số lượng phòng loại 1: "+r1)
        mylist.insert(END," ")
        mylist.insert(END,"Số lượng phòng loại 2: "+r2)
        mylist.insert(END," ")
        mylist.insert(END,"Số lượng phòng loại 3: "+r3)
        mylist.insert(END," ")
        mylist.insert(END,"Số lượng phòng loại 1 bạn đã đặt: "+str(w1))
        mylist.insert(END," ")
        mylist.insert(END,"Số lượng phòng loại 2 bạn đã đặt: "+str(w2))
        mylist.insert(END," ")
        mylist.insert(END,"Số lượng phòng loại 3 bạn đã đặt: "+str(w3))
        mylist.place(x=12,y=220)

        # lable
        lb1 = tk.Label(self, text="BOOKING HOTEL", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb1.pack()
        lb2 = tk.Label(self, text="ĐẶT PHÒNG", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb2.pack()
        lb3 = tk.Label(self, text="Chọn loại phòng:", font=("Times new roman", 10), fg="black", bg="#66ffcc")
        lb3.place(x=30, y=120)  # 0 so voi frame
        lb3 = tk.Label(self, text="Chọn số lượng:", font=("Times new roman", 10), fg="black", bg="#66ffcc")
        lb3.place(x=30, y=150)
        #Tạo hộp chọn Combobox
        typeroom = Combobox(self,width=3,height=5)
        numroom = Combobox(self,width=5,height=5)
        #Các giá trị của hộp chọn
        typeroom['values']= (1, 2, 3)
        numroom['values']=(1,2,3,4,5,6,7,8,9,10)
        
        #Thiết lập giá trị được chọn
        typeroom.current(0)
        numroom.current(0)

        #đặt vào vị trí
        typeroom.place(x=140,y=120)
        numroom.place(x=140,y=150)

        # button
        bt1 = Button(self, text='Book', font=("Times new roman", 12),command=lambda: sendbookroom1(master,self,r1,r2,r3,typeroom,numroom)).place(x=320, y=150)
        bt2 = Button(self, text='THANH TOÁN', font=("Times new roman", 15),command=lambda: sendbookroom2(master,self)).place(x=350, y=450)

#frame 8 (thông báo đặt thành công phòng và hỏi có muốn đặt nữa không?)
class Booksuccess(tk.Frame):
    def __init__(self, master):
        tk.Frame.__init__(self, master)
        self["bg"] = "#66ffcc"
        self.pack(ipadx=500,ipady=500,expand=True)
        # image
        image1 = Image.open("main.jpg")
        image1 = image1.resize((500, 500))
        test = ImageTk.PhotoImage(image1)

        # lable
        label0 = tk.Label(self, image=test)
        label0.image = test
        label0.place(x=0, y=0)

        # lable
        lb1 = tk.Label(self, text="BOOKING HOTEL", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb1.pack()
        lb2 = tk.Label(self, text="ĐẶT PHÒNG", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb2.pack()
        lb3 = tk.Label(self, text="ĐÃ ĐẶT PHÒNG THÀNH CÔNG", font=("Times new roman", 20), fg="black", bg="#66ffcc")
        lb3.pack()


        # button
        bt1 = Button(self, text='Tiếp tục đặt phòng', font=("Times new roman", 12),command=lambda: master.switch_frame(Clientready)).place(x=200, y=150)
        bt2 = Button(self, text='THANH TOÁN', font=("Times new roman", 15),command=lambda: sendbookroom2(master,self)).place(x=350, y=150)

#frame 9 (Recipt)
class Recipt(tk.Frame):
    def __init__(self, master):
        tk.Frame.__init__(self, master)
        self["bg"] = "#66ffcc"
        self.pack(ipadx=500,ipady=500,expand=True)
        # image
        image1 = Image.open("main.jpg")
        image1 = image1.resize((500, 500))
        test = ImageTk.PhotoImage(image1)

        # lable
        label0 = tk.Label(self, image=test)
        label0.image = test
        label0.place(x=0, y=0)

        #BIll
        global w1,w2,w3,r1,r2,r3,ks
        Tonghang=recvlist_lv2(client)
        msg="1"
        client.sendall(msg.encode(FORMAT))
        Tongtien=client.recv(1024).decode(FORMAT)
        scrollbar= Scrollbar(self)
        scrollbar.height=400
        scrollbar.place(x=480,y=100,height=400)
        mylist=Listbox(self,width=60,height=12,yscrollcommand=scrollbar.set)
        mylist.insert(END,"Hóa đơn đặt phòng tại khác sạn "+ks)
        mylist.insert(END," ")
        mylist.insert(END,"Danh sách phòng khách hàng đã đặt:")
        mylist.insert(END," ")
        for room in Tonghang:
            mylist.insert(END,"Phòng " + str(Tonghang.index(room) + 1) + ":")
            outputRoomInfo2(mylist,room)
        mylist.insert(END," ")
        mylist.insert(END,"Tổng tiền: "+Tongtien+" VNĐ")
        mylist.place(x=12,y=220)
        scrollbar.config(command=mylist.yview)

        # lable
        lb1 = tk.Label(self, text="BOOKING HOTEL", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb1.pack()
        lb2 = tk.Label(self, text="ĐẶT PHÒNG", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb2.pack()
        lb3 = tk.Label(self, text="ĐÃ ĐẶT PHÒNG THÀNH CÔNG", font=("Times new roman", 20), fg="black", bg="#66ffcc")
        lb3.pack()


        # button
        bt1 = Button(self, text='TRỞ VỀ MENU', font=("Times new roman", 12),command=lambda: master.switch_frame(ClientMenu)).place(x=200, y=430)


#frame 10 (CANCEL a ROOM)
class ClientCancel(tk.Frame):
    def __init__(self, master):
        msg="2"
        client.sendall(msg.encode(FORMAT))

        tk.Frame.__init__(self, master)
        self["bg"] = "#66ffcc"
        self.pack(ipadx=500,ipady=500,expand=True)

        # image
        image1 = Image.open("main.jpg")
        image1 = image1.resize((500, 500))
        test = ImageTk.PhotoImage(image1)

        # lable
        label0 = tk.Label(self, image=test)
        label0.image = test
        label0.place(x=0, y=0)

        # lable
        lb1 = tk.Label(self, text="BOOKING HOTEL", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb1.pack()
        lb2 = tk.Label(self, text="HỦY ĐẶT PHÒNG", font=("Times new roman", 30), fg="black", bg="#66ffcc")
        lb2.pack()
        lb3 = tk.Label(self, text="Tên khách sạn:", font=("Times new roman", 10), fg="black", bg="#66ffcc")
        lb3.place(x=30, y=120)  

        #lấy thông tin khách sạn đã đặt phòng 
        bookedList = recvlist_lv2(client)

        #Tạo hộp chọn Combobox
        hname = Combobox(self,width=50,height=10)

        #Các giá trị của hộp chọn
        hname['values']= (bookedList)
        
        #Thiết lập giá trị được chọn
        hname.current(0)

        #đặt vào vị trí
        hname.place(x=160,y=120)

        # button
        bt1 = Button(self, text='Chọn', font=("Times new roman", 12),command=lambda: canceltheroom(master,hname)).place(x=320, y=150)
        bt2 = Button(self, text='Back', command=lambda: master.switch_frame(ClientMenu)).place(x=20, y=450)