﻿
import tkinter as tk

import UI_Client_function as ui
from tkinter import *
import socket
from tkinter import Button, Frame, font
from tkinter.constants import BOTTOM, COMMAND, FALSE
from turtle import showturtle, width, window_height, window_width
from PIL import Image, ImageTk
from tkinter import messagebox
from setuptools import Command




app=ui.Frameapp()
app_width=500
app_height=500
app.title("CLIENT")
app.geometry("500x500")
app["bg"]="#66ffcc"
app.protocol("WM_DELETE_WINDOW", func=lambda: ui.on_closing(app))
app.resizable(width=FALSE,height=FALSE)

app.mainloop()
#ui.window.mainloop()