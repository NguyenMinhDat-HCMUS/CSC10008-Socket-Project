import tkinter as tk

import UI_Client_function as ui
from tkinter import Button, Frame, font
from tkinter.constants import BOTTOM, COMMAND, FALSE
from turtle import showturtle, width, window_height, window_width
from PIL import Image, ImageTk
from tkinter import messagebox




app=ui.Frameapp()
app_width=500
app_height=500
app.title("CLIENT")
app.geometry("500x500")
app["bg"]="#66ffcc"
app.resizable(width=FALSE,height=FALSE)

app.mainloop()
#ui.window.mainloop()