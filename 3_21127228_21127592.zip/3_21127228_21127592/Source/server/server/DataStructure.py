class User:
    def __init__(self, username, password, bankid):
        self.username = username
        self.password = password
        self.bankid = bankid

class Room:
    def __init__(self, rid, status, rtype, price):
        self.id = rid
        self.status = status
        self.type = rtype
        self.price = price

class Hotel:
    def __init__(self, name, capac, roomList):
        self.name = name
        self.capac = capac
        self.roomList = roomList

class HotelBase:
    def __init__(self, capac, hotelList):
        self.capac = capac
        self.hotelList = hotelList



