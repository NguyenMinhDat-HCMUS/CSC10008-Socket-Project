﻿import socket
import threading
from DataStructure import Hotel, HotelBase
from datetime import datetime
from datetime import time
from datetime import date

host = '127.0.0.1'
port = 65500
MAX_NUM_CLIENT = 10
FORMAT = 'utf-8'
SIGNUP = 'signup'
LOGIN = 'login'
START = 'start'
USER_DATA_PATH = "UserDataBase.txt"
HOTEL_DATA_PATH = "HotelDataBase.txt"

#extractRoomInfo
def extractRoomInfo(msg):
    info = []
    tmp = -1
    pre = 0
    suf = int(len(msg))

    while True:
        tmp = msg.find(' ', pre)
        if tmp == -1:
            info.append(msg[pre:suf])
            break
        info.append(msg[pre:tmp])
        pre = tmp + 1
    return info

#AccessHotelData
def AccessHotelData():
    fin = open(HOTEL_DATA_PATH, "r")

    hotel_base = HotelBase(int(fin.readline().removesuffix('\n')), [])

    for _ in range(0, hotel_base.capac):
        hotel = Hotel(str(fin.readline().removesuffix('\n')), int(fin.readline().removesuffix('\n')), [])
        for _ in range(0, hotel.capac):
            room = extractRoomInfo(fin.readline().removesuffix('\n'))
            hotel.roomList.append(room)
        hotel_base.hotelList.append(hotel)
    
    fin.close()
    return hotel_base

#UpdateHotelData
def UpdateHotelData(hotel_base):    
    fout = open(HOTEL_DATA_PATH, "w")

    fout.writelines(str(hotel_base.capac) + '\n')

    for hotel in hotel_base.hotelList:
        fout.write(str(hotel.name) + '\n')
        fout.write(str(hotel.capac) + '\n')
        for room in hotel.roomList:
            #fout.writelines(room[0] + " " + room[1] + " " + room[2] + " " + room[3] + " " + room[4] + " " + room[5] + " " + room[6] + " " + room[7] + " " + room[8] + " " + room[9] + "\n")
            fout.writelines(room[0] + " " + room[1] + " " + room[2] + " " + room[3])
            for i in range(0, int(room[1])):
                for j in range(0, 10):
                    fout.write(" " + room[4 + 10 * i + j])
            fout.write("\n")            

    fout.close()

#printHotelBase
def printHotelBase(hotel_base : HotelBase):
    print("So luong khach san: " + str(hotel_base.capac))
    print("Thong tin chi tiet tung khach san")

    for hotel in hotel_base.hotelList:
        print("Ten khach san: " + hotel.name)
        print("So luong phong: " + str(hotel.capac))
        for room in hotel.roomList:
            print(room)

#hotel_base = AccessHotelData()
#printHotelBase(hotel_base)

#AccessUserData
def AccessUserData():
    user_base = []
    fin = open(USER_DATA_PATH, "r")
    while True:
        user_account = []    
        usrnm = fin.readline().removesuffix('\n')
        usrpw = fin.readline().removesuffix('\n')
        usrid = fin.readline().removesuffix('\n')

        if usrnm == '' and usrpw == '' and usrid == '':
            break
        user_account.append(usrnm)
        user_account.append(usrpw)
        user_account.append(usrid)

        user_base.append(user_account)
    fin.close()
    return user_base

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((host, port))
server.listen()

#sendlist
def sendlist(conn, info):
    for item in info:
        conn.send(item.encode(FORMAT))
        conn.recv(1024)

    conn.send("end".encode(FORMAT))

#sendlist_lv2
def sendlist_lv2(conn, info):
    for item in info:
        sendlist(conn, item)
        conn.recv(1024)

    sendlist(conn, [])

#recvlist
def recvlist(conn):
    info = []
    msg = conn.recv(1024).decode(FORMAT)

    while msg != "end":
        info.append(msg)
        conn.send(msg.encode(FORMAT))
        msg = conn.recv(1024).decode(FORMAT)        

    return info

#recvlist_lv2
def recvlist_lv2(client):
    info = []
    msg = recvlist(client)

    while msg != []:
        info.append(msg)
        client.send("Y".encode(FORMAT))
        msg = recvlist(client)

    return info

#findUserAccount
def findUserAccount(user_account):
    user_base = AccessUserData()
    for user in user_base:
        if user[0] == user_account[0]:
            return user_base.index(user)
    return -1

#serverSignup
def serverSignup(conn):
    user_account = recvlist(conn)

    if findUserAccount(user_account) != -1:
        msg = "Username da ton tai!"
        print(msg)
        conn.send(msg.encode(FORMAT))
        conn.recv(1024).decode(FORMAT)

        rslt = '0'
        conn.send(rslt.encode(FORMAT))
        conn.recv(1024).decode(FORMAT)
        return 0
    else:
        msg = "Sign up successfully"
        print(msg)
        conn.send(msg.encode(FORMAT))
        conn.recv(1024).decode(FORMAT)

        rslt = '1'
        conn.send(rslt.encode(FORMAT))
        conn.recv(1024).decode(FORMAT)

    fout = open(USER_DATA_PATH, "a")

    fout.write(user_account[0] + '\n')
    fout.write(user_account[1] + '\n')
    fout.write(user_account[2] + '\n')

    fout.close()

    return 1

#user_base = AccessUserData()
#print(user_base)

#serverLogin
def serverLogin(conn):
    user_account = recvlist(conn)
    idx = findUserAccount(user_account)
    user_base = AccessUserData()

    if idx == -1:
        msg = "Username khong ton tai!"
        print(msg)
        conn.send(msg.encode(FORMAT))
        conn.recv(1024).decode(FORMAT)

        rslt = '0'
        conn.send(rslt.encode(FORMAT))
        conn.recv(1024).decode(FORMAT)
        account = []
        return account
    else:
        if user_base[idx][1] == user_account[1]:
            msg = "Log in successfully"
            print(msg)
            conn.send(msg.encode(FORMAT))
            conn.recv(1024).decode(FORMAT)

            rslt = '1'
            conn.send(rslt.encode(FORMAT))
            conn.recv(1024).decode(FORMAT)
            return user_account
        else:
            msg = "Wrong password!"
            print(msg)
            conn.send(msg.encode(FORMAT))
            conn.recv(1024).decode(FORMAT)

            rslt = '0'
            conn.send(rslt.encode(FORMAT))
            conn.recv(1024).decode(FORMAT)
            account = []
            return account

#findHotel        
def findHotel(hotelName):
    hotel_base = AccessHotelData()
    for hotel in hotel_base.hotelList:
        if hotelName == hotel.name:
            return hotel_base.hotelList.index(hotel)
    return -1

#NgayTruocNgaySau
def NgayTruocNgaySau(n1, n2):
    if int(n1[2]) > int(n2[2]):
        return False
    elif int(n1[2]) < int(n2[2]):
        return True
    else:
        if int(n1[1]) > int(n2[1]):
            return False
        elif int(n1[1]) < int(n2[1]):
            return True
        else:
            if int(n1[0]) > int(n2[0]):
                return False
    return True

#checkTimePeriodTraCuu
def checkTimePeriodTraCuu(p1, p2):
    if NgayTruocNgaySau(p1[2], p2[0]):
        return True
    elif NgayTruocNgaySau(p2[1], p1[1]):
        return True
    
    return False

#checkTimePeriodDatPhong
def checkTimePeriodDatPhong(p1, p2):
    if NgayTruocNgaySau(p1[2], p2[1]):
        return True
    elif NgayTruocNgaySau(p2[2], p1[1]):
        return True
    
    return False
#khoảng cách giữa 2 ngày
def khoangCachNgay(d1,m1,y1,d2,m2,y2):
    if(y2<y1):
        return -1
    elif(m2<m1 and y2==y1):
        return -1
    elif(d2<d1 and m2==m1 and y2==y1):
        return -1
    t=0
    while(y2>=y1):
        if(y2==y1 and m2==m1):
            t=t+d2-d1
            return t
        else:
            if(m1==4 or m1==6 or m1==9 or m1==11):
                t=t+30-d1 
            elif(m1==1 or m1==3 or m1==5 or m1==7 or m1==8 or m1==10 or m1==12):
                t=t+31-d1
            elif(m1==2):
                if((y1%4==0 and y1%100!=0) or (y1%400==0)):
                    t=t+29-d1 
                else:
                    t=t+28-d1 
            m1=m1+1
            d1=0
            if(m1==13):
                y1=y1+1
                m1=1
    return t

#findPhongTrongTraCuu
def findPhongTrongTraCuu(roomList, timePeriod):
    sparseRoom = []
    for room in roomList:
        if room[1] == '0':
            sparseRoom.append(room)
        else:
            check = True
            for i in range(0, int(room[1])):
                p1 = [room[4 + 10 * i + 3], room[4 + 10 * i + 4], room[4 + 10 * i + 5]]
                p2 = [room[4 + 10 * i + 6], room[4 + 10 * i + 7], room[4 + 10 * i + 8]]
                timeSample = [p1, p2]
                if checkTimePeriodTraCuu(timePeriod, timeSample) == False:
                    check = False
                    break
            if check == True:
                room[1]='0'
                sparseRoom.append(room)
    return sparseRoom

#findPhongTrongDatPhong
def findPhongTrongDatPhong(roomList, timePeriod):
    sparseRoom = []
    for room in roomList:
        if room[1] == '0':
            sparseRoom.append(room)
        else:
            check = True
            for i in range(0, int(room[1])):
                p0 = [room[4 + 10 * i + 0], room[4 + 10 * i + 1], room[4 + 10 * i + 2]]
                p1 = [room[4 + 10 * i + 3], room[4 + 10 * i + 4], room[4 + 10 * i + 5]]
                p2 = [room[4 + 10 * i + 6], room[4 + 10 * i + 7], room[4 + 10 * i + 8]]
                timeSample = [p0, p1, p2]
                if checkTimePeriodDatPhong(timePeriod, timeSample) == False:
                    check = False
                    break
            if check == True:
                sparseRoom.append(room)
    return sparseRoom

#kiểm tra danh sách đã có ngày đặt phòng đó chưa?
def checkdate(bookedList,dd,mm,yy):
    if(bookedList==[]): 
        return True
    else:
        for info in bookedList:
            if(info[0]==dd and info[1]==mm and info[2]==yy):
                return False
        return True
#findUser
def findUser(hotel, username,hotelname,bookedList):
    info = []
    for room in hotel.roomList:
        for i in range(0, int(room[1])):
            if (room[4 + 10 * i + 9] == username and checkdate(bookedList,room[4 + 10 * i],room[5 + 10 * i],room[6 + 10 * i])==True):
                for j in range(0, 3):
                    info.append(room[4 + 10 * i + j])
                info.append(hotelname)
                bookedList.append(info)
                info=[]
    return info

#findPhongTrong
def findPhongTrong(roomList):
    sparseRoom = []
    for room in roomList:
        if room[1] == '1':
            sparseRoom.append(room)

    return sparseRoom

#findPhongTheoLoai
def findPhongTheoLoai(roomList, tp):
    newList = []
    for room in roomList:
        if room[2] == tp:
            newList.append(room)
    return newList

#datPhongTheoLoai
def datPhongTheoLoai(roomList, num):
    gioHang = []
    for i in range(0, num):
        roomList[i][1] = '0'
        gioHang.append(roomList[i])
    return gioHang

#HuythongtinUser
def HuyThongTinUser(hotel, username,ndat):
    for room in hotel.roomList:
        i = 0
        while i < int(room[1]):
            if (room[4 + 10 * i + 9] == username and room[4+10*i]==ndat[0] and room[5+10*i]==ndat[1] and room[6+10*i]==ndat[2]):
                for j in range(0, 10):
                    room.pop(4 + 10 * i)
                room[1] = str(int(room[1]) - 1)
            i = i + 1

#findPhongtheloai
def findPhongTheoLoai(roomList, tp):
    newList = []
    for room in roomList:
        if room[2] == tp:
            newList.append(room)
    return newList

#datphongtheoloai
def datPhongTheoLoai(roomList, num, timePeriod, userName):
    gioHang = []
    for i in range(0, num):
        roomList[i][1] = str(int(roomList[i][1]) + 1)

        for day in timePeriod:
            for element in day:
                roomList[i].append(element)

        roomList[i].append(userName)

        gioHang.append(roomList[i])
    return gioHang

#hủy phòng
def huyPhong(hotelName, user_account,ndat):
    hotel_base = AccessHotelData()
    for hotel in hotel_base.hotelList:
        if hotel.name == hotelName:
            HuyThongTinUser(hotel, user_account[0],ndat)
    UpdateHotelData(hotel_base)


#updateHotelData           
def updateHotelData(hotelName, gioHang):
    hotel_base = AccessHotelData()

    idx = findHotel(hotelName)
    for roomA in gioHang:
        for roomB in hotel_base.hotelList[idx].roomList:
            if roomA[0] == roomB[0]:
                idx2 = hotel_base.hotelList[idx].roomList.index(roomB)
                hotel_base.hotelList[idx].roomList[idx2].clear()

                for element in roomA:
                    hotel_base.hotelList[idx].roomList[idx2].append(element)
                break

    return hotel_base


#findBookedHotel
def findBookedHotel(user_account):
    bookedList = []
    hotel_base = AccessHotelData()
    for hotel in hotel_base.hotelList:
        timeInfo = findUser(hotel, user_account[0],hotel.name,bookedList)
        

    return bookedList

#login
def login(conn,addr):
    msg = conn.recv(1024).decode(FORMAT)
    if msg == 'x':
        print("Client ", addr, " disconnected")
        return
    if msg =="1":
        print("Client ", addr, " press login")
        #xu ly dang nhap
        user_account=recvlist(conn)
        idx = findUserAccount(user_account)
        user_base = AccessUserData()
        if idx == -1:
            msg = "Username không tồn tại!"
            print(msg)
            conn.send(msg.encode(FORMAT))
            conn.recv(1024).decode(FORMAT)

            rslt = 'False'
            conn.send(rslt.encode(FORMAT))
            conn.recv(1024).decode(FORMAT)
            #login(conn,addr) 
            #return login(conn,add)
            account = login(conn,addr)
            return account
        else:
            if user_base[idx][1] == user_account[1]:
                msg = "Đăng nhập thành công!"
                print(msg)
                conn.send(msg.encode(FORMAT))
                conn.recv(1024).decode(FORMAT)

                rslt = 'True'
                conn.send(rslt.encode(FORMAT))
                conn.recv(1024).decode(FORMAT)
                return user_account
            else:
                msg = "Sai mật khẩu!"
                print(msg)
                conn.send(msg.encode(FORMAT))
                conn.recv(1024).decode(FORMAT)

                rslt = 'False'
                conn.send(rslt.encode(FORMAT))
                conn.recv(1024).decode(FORMAT)
                account = login(conn,addr)
                return account 
        #neu dung thi truy cap menu
        return user_account

    else:
        print("Client ", addr, " is sign up")
        return signup(conn,addr)
        

#signup
def signup(conn,addr):
    msg = conn.recv(1024).decode(FORMAT)
    if msg == 'x':
        print("Client ", addr, " disconnected")
        return
    if msg =="1":
        print("Client ", addr, " return to login")
        return login(conn,addr)
    else:
        print("Client ", addr, " have signed up")
        conn.send(msg.encode(FORMAT))
        #xu ly dangky
        user_account = recvlist(conn)
        if findUserAccount(user_account) != -1:
            msg = "Username đã tồn tại!"
            print(msg)
            conn.send(msg.encode(FORMAT))
            conn.recv(1024).decode(FORMAT)

            rslt = '0'
            conn.send(rslt.encode(FORMAT))
            conn.recv(1024).decode(FORMAT)
            return signup(conn,addr)
        else:
            msg = "Đăng ký thành công"
            print(msg)
            conn.send(msg.encode(FORMAT))
            conn.recv(1024).decode(FORMAT)

            rslt = '1'
            conn.send(rslt.encode(FORMAT))
            conn.recv(1024).decode(FORMAT)

        fout = open(USER_DATA_PATH, "a")

        fout.write(user_account[0] + '\n')
        fout.write(user_account[1] + '\n')
        fout.write(user_account[2] + '\n')

        fout.close()
        #neu dung thi truy cap menu
        msg = conn.recv(1024).decode(FORMAT)
        print("Client ", addr, "return to login")
        return login(conn,addr)

#tracuu
def search(conn,addr,account):
    print("Client ", addr, " enter the Search")
    msg = conn.recv(1024).decode(FORMAT)
    if msg == 'x':
        print("Client ", addr, " disconnected")
        return
    elif msg=="1":
        print("Da nhan thong tin search tu Client", addr)
        conn.sendall(msg.encode(FORMAT))
        hotelName = conn.recv(1024).decode(FORMAT)
        idx = findHotel(hotelName)
        if idx == -1:
            rep = "0"
            conn.send(rep.encode(FORMAT))
            return search(conn,addr,account)
        else:
            rep = "3"
            conn.send(rep.encode(FORMAT))
            timePeriod = recvlist_lv2(conn)
            print(timePeriod)
            hotel_base = AccessHotelData()
            sparseRoom = findPhongTrongTraCuu(hotel_base.hotelList[idx].roomList, timePeriod)
            sendlist_lv2(conn, sparseRoom)
            return search(conn,addr,account)
    elif(msg=="3"):
        print("Client ",addr," return to Menu")
        return menu(conn,addr,account)

#dat phong
def bookroom(conn,addr,account):
    print("Client ", addr, " enter the BookRoom")
    msg = conn.recv(1024).decode(FORMAT)
    if msg == 'x':
        print("Client ", addr, " disconnected")
        return
    elif msg=="1":
        print("Đã nhận thông tin đặt phòng từ  Client", addr)
        conn.sendall(msg.encode(FORMAT))
        hotelName = conn.recv(1024).decode(FORMAT)
        idx = findHotel(hotelName)
        if idx == -1:
            rep = "0"
            conn.send(rep.encode(FORMAT))
            return bookroom(conn,addr,account)
        else:
            rep = "3"
            conn.send(rep.encode(FORMAT))
            timePeriod = recvlist_lv2(conn)
            print(timePeriod)
            batdaudatphong(conn,timePeriod,hotelName,idx,account)
    elif(msg=="3"):
        print("Client ",addr," return to Menu")
        return menu(conn,addr,account)

def batdaudatphong(conn,timePeriod,hotelName,idx,user_account):
    while(True):
        hotel_base = AccessHotelData()
        r1=1
        r2=2
        r3=3
        roomList1 = findPhongTheoLoai(hotel_base.hotelList[idx].roomList, str(r1))
        roomList2 = findPhongTheoLoai(hotel_base.hotelList[idx].roomList, str(r2))
        roomList3 = findPhongTheoLoai(hotel_base.hotelList[idx].roomList, str(r3))
        sparseRoom1 = findPhongTrongDatPhong(roomList1, timePeriod)
        sparseRoom2 = findPhongTrongDatPhong(roomList2, timePeriod)
        sparseRoom3 = findPhongTrongDatPhong(roomList3, timePeriod)
        conn.send(hotelName.encode(FORMAT))
        hotelName=conn.recv(1024).decode(FORMAT)
        conn.send(str(len(sparseRoom1)).encode(FORMAT))
        hotelName=conn.recv(1024).decode(FORMAT)
        conn.send(str(len(sparseRoom2)).encode(FORMAT))
        hotelName=conn.recv(1024).decode(FORMAT)
        conn.send(str(len(sparseRoom3)).encode(FORMAT))
        msg = conn.recv(1024).decode(FORMAT)
        if msg == 'x':
            print("Client ", addr, " disconnected")
            return
        elif msg=="1":
            print("Đã nhận thông tin loại phòng và số phòng từ  Client", addr)
            conn.sendall(msg.encode(FORMAT))
            gioHangLon = []
            totalPrice = 0

            numRoom1 = conn.recv(1024).decode(FORMAT)
            d1=int(numRoom1)
            if(d1>0):
                gioHang1 = datPhongTheoLoai(sparseRoom1, int(numRoom1), timePeriod, user_account[0])
                hotel_base = updateHotelData(hotelName, gioHang1)
                UpdateHotelData(hotel_base)
                for room in gioHang1:
                    gioHangLon.append(room)
                    totalPrice = totalPrice + khoangCachNgay(int(timePeriod[1][0]), int(timePeriod[1][1]), int(timePeriod[1][2]), int(timePeriod[2][0]), int(timePeriod[2][1]), int(timePeriod[2][2])) * int(room[3])
            conn.sendall(msg.encode(FORMAT))

            numRoom2 = conn.recv(1024).decode(FORMAT)
            d2=int(numRoom2)
            if(d2>0):
                gioHang2 = datPhongTheoLoai(sparseRoom2, int(numRoom2), timePeriod, user_account[0])
                hotel_base = updateHotelData(hotelName, gioHang2)
                UpdateHotelData(hotel_base)
                for room in gioHang2:
                    gioHangLon.append(room)
                    totalPrice = totalPrice + khoangCachNgay(int(timePeriod[1][0]), int(timePeriod[1][1]), int(timePeriod[1][2]), int(timePeriod[2][0]), int(timePeriod[2][1]), int(timePeriod[2][2])) * int(room[3])
            conn.sendall(msg.encode(FORMAT))

            numRoom3 = conn.recv(1024).decode(FORMAT)
            d3=int(numRoom3)
            if(d3>0):
                gioHang3 = datPhongTheoLoai(sparseRoom2, int(numRoom3), timePeriod, user_account[0])
                hotel_base = updateHotelData(hotelName, gioHang3)
                UpdateHotelData(hotel_base)
                for room in gioHang3:
                    gioHangLon.append(room)
                    totalPrice = totalPrice + khoangCachNgay(int(timePeriod[1][0]), int(timePeriod[1][1]), int(timePeriod[1][2]), int(timePeriod[2][0]), int(timePeriod[2][1]), int(timePeriod[2][2])) * int(room[3])
            
            sendlist_lv2(conn, gioHangLon)
            msg = conn.recv(1024).decode(FORMAT)
            conn.sendall(str(totalPrice).encode(FORMAT))
            msg = conn.recv(1024).decode(FORMAT)
            return menu(conn,addr,user_account)

#huy phong
def cancelroom(conn,addr,account):
    print("Client ", addr, " enter the CancelRoom")
    bookedList = findBookedHotel(account)
    sendlist_lv2(conn, bookedList)
    msg = conn.recv(1024).decode(FORMAT)
    if msg == 'x':
        print("Client ", addr, " disconnected")
        return
    elif(msg=="1"):
        conn.sendall(msg.encode(FORMAT))
        hotelname=conn.recv(1024).decode(FORMAT)
        conn.sendall(msg.encode(FORMAT))
        ndat=recvlist(conn)
        conn.sendall(msg.encode(FORMAT))
        huyPhong(hotelname,account,ndat)
        print("Client ", addr, " hủy đơn đặt phòng vào ngày "+ndat[0]+"/"+ndat[1]+"/"+ndat[2]+" thành công")
        msg = conn.recv(1024).decode(FORMAT)
        return menu(conn,addr,account)
    elif(msg=="2"):
        return cancelroom(conn,addr,account)
    elif(msg=="3"):
        print("Client ",addr," return to Menu")
        return menu(conn,addr,account)

#menu
def menu(conn,addr,account):
    print("Client ", addr, " enter the Menu")
    msg = conn.recv(1024).decode(FORMAT)
    if msg == 'x':
        print("Client ", addr, " disconnected")
        return
    elif(msg=="1"):
        print("Client ", addr, " đang tra cứu")
        hotelNameList = []
        hotel_base = AccessHotelData()
        for hotel in hotel_base.hotelList:
            hotelNameList.append(hotel.name)
        sendlist(conn, hotelNameList)
        print("Đã gửi về danh sách khách sạn cho Client ", addr)
        return search(conn,addr,account)
    elif(msg=="2"):
        print("Client ", addr, " đang đặt phòng")
        hotelNameList = []
        hotel_base = AccessHotelData()
        for hotel in hotel_base.hotelList:
            hotelNameList.append(hotel.name)
        sendlist(conn, hotelNameList)
        print("Đã gửi về danh sách khách sạn cho Client ", addr)
        return bookroom(conn,addr,account)
    elif(msg=="3"):
        print("Client ", addr, " đang hủy phòng")
        return cancelroom(conn,addr,account)
    elif(msg=="4"):
        account=[]
        msg="1"
        conn.send(msg.encode(FORMAT))
        print("Client ", addr, " log out")
        return account
#handleConn
def handleConn(conn, addr):
    try:
        print("Client ", addr, " connected")
        while True:
            msg = conn.recv(1024).decode(FORMAT)
            if msg == 'x':
                print("Client ", addr, " disconnected")
                return
            else:
                if msg =="1":
                    print("Client ", addr, " is login")
                    account = login(conn,addr)
                    if account ==[]:
                        continue
                    else:
                        username = account[0]
                        password = account[1]
                    print("User: " + username + " (" + password + ")")
                    msg = conn.recv(1024).decode(FORMAT)
                    account=menu(conn,addr,account)
                    if account ==[]:
                        continue

    except:
        print("Connection error")

nClient = 0
while nClient < MAX_NUM_CLIENT:
    try:
        conn, addr = server.accept()

        thr = threading.Thread(target=handleConn, args=(conn, addr))
        thr.daemon = True
        thr.start()
    except:
        print("Error")

    nClient += 1


print("End")
input()
server.close()
